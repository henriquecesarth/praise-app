import { validatePublishEnvironment } from './src/config/publish-guard';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { VitePWA } from 'vite-plugin-pwa';

// https://vitejs.dev/config/
export default defineConfig(({ command, mode }) => {
validatePublishEnvironment(process.env, command, mode);
return {
define: { 'globalThis.__LOUVAIO_VERIFIED_API__': JSON.stringify(['preview','production'].includes(process.env.VERCEL_ENV || '') ? process.env.VITE_API_URL : ''), 'globalThis.__LOUVAIO_BUILD_ENV__': JSON.stringify(process.env.VERCEL_ENV || 'local') },
  plugins: [
    react(),
    tailwindcss(),
    VitePWA({
      registerType: 'prompt',
      injectRegister: null,
      manifest: {
        name: 'LouvAIO - Gestão de Louvor',
        short_name: 'LouvAIO',
        description: 'Aplicativo de música e conteúdo cristão.',
        lang: 'pt-BR',
        theme_color: '#0F2A1F',
        background_color: '#F5EFE6',
        display: 'standalone',
        orientation: 'portrait',
        start_url: '/',
        scope: '/',
        icons: [
          {
            src: '/branding/pwa/icon-192.png',
            sizes: '192x192',
            type: 'image/png',
            purpose: 'any',
          },
          {
            src: '/branding/pwa/icon-512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'any',
          },
          {
            src: '/branding/pwa/icon-maskable-512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          },
        ],
      },
      workbox: {
        cacheId: 'louvaio-app-shell-v1',
        cleanupOutdatedCaches: true,
        globPatterns: ['**/*.{js,css,html,ico,png,svg,jpg}', 'audio/upright-kw/*.wav'],
        navigateFallback: null,
        runtimeCaching: [
          {
            urlPattern: ({ request, url }) => request.mode === 'navigate' && url.pathname === '/exercicios-vocais',
            handler: 'NetworkFirst',
            options: {
              cacheName: 'louvaio-vocal-player-navigation-v1',
              precacheFallback: { fallbackURL: '/index.html' },
            },
          },
          {
            urlPattern: ({ request }) => request.mode === 'navigate',
            handler: 'NetworkOnly',
            options: {
              precacheFallback: {
                fallbackURL: '/offline.html',
              },
            },
          },
        ],
      },
    }),
  ],
  server: {
    port: 5173,
  },
}; });
