package com.louvaio.louvaio_mobile

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.view.ViewGroup
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.webviewflutter.WebViewFlutterAndroidExternalApi
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.Future
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.sin

class MainActivity : FlutterActivity() {

    companion object {
        private const val CHANNEL = "com.louvaio.louvaio_mobile/share_intent"
        private const val READ_TIMEOUT_MS = 15_000L
        private const val MAX_PENDING_SHARES = 8
        private const val AUDIO_CHANNEL = "com.louvaio.mobile/vocal_audio"
    }

    // Keep IO bounded even when a remote provider ignores cancellation.
    private val ioExecutor = boundedExecutor("shared-import-io")
    private val cancellationExecutor = boundedExecutor("shared-import-cancel")
    private val mainHandler = Handler(Looper.getMainLooper())
    private var shareIntentHandler: ShareIntentHandler? = null
    private var methodChannel: MethodChannel? = null
    private val requests = ArrayDeque<ShareRequest>()
    private var initialRequest: ShareRequest? = null
    private var initialConsumed = false
    private var initialResult: MethodChannel.Result? = null
    private var destroyed = false
    private var nextRequestId = 0L
    private val vocalLock = Any()
    private var vocalTrack: AudioTrack? = null
    private var vocalRelease: Runnable? = null
    private var vocalRemainingMs = 0L
    private var vocalReleaseAtMs = 0L
    private var vocalGeneration = 0

    private class ShareRequest(
        val initial: Boolean,
        val id: String,
        val read: ShareIntentHandler.ReadOperation,
    ) {
        var future: Future<*>? = null
        var timeout: Runnable? = null
        var complete = false
        var payload: Map<String, Any?>? = null
    }

    private fun boundedExecutor(name: String) = ThreadPoolExecutor(
        1, 1, 0L, TimeUnit.MILLISECONDS, ArrayBlockingQueue(MAX_PENDING_SHARES),
        { runnable -> Thread(runnable, name).apply { isDaemon = true } },
        ThreadPoolExecutor.AbortPolicy(),
    )

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        shareIntentHandler = ShareIntentHandler(applicationContext)
        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, AUDIO_CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "pause" || call.method == "resume") {
                synchronized(vocalLock) {
                    val track = vocalTrack
                    if (track == null) {
                        result.error("NO_AUDIO", "No vocal sequence is active", null)
                        return@setMethodCallHandler
                    }
                    try {
                        if (call.method == "pause") {
                            track.pause()
                            vocalRemainingMs = (vocalReleaseAtMs - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
                            vocalRelease?.let(mainHandler::removeCallbacks)
                            vocalRelease = null
                        } else {
                            track.play()
                            scheduleVocalRelease(track, vocalRemainingMs)
                        }
                        result.success(null)
                    } catch (error: Exception) {
                        result.error("AUDIO", error.message, null)
                    }
                }
                return@setMethodCallHandler
            }
            if (call.method == "stop") {
                stopVocalAudio()
                result.success(null)
                return@setMethodCallHandler
            }
            if (call.method != "playSequence") { result.notImplemented(); return@setMethodCallHandler }
            val notes = call.argument<List<Int>>("notes") ?: emptyList()
            val durations = call.argument<List<Number>>("durations")?.map { it.toDouble() } ?: emptyList()
            val bpm = (call.argument<Int>("bpm") ?: 80).coerceIn(40, 180)
            val metronome = call.argument<Boolean>("metronome") ?: true
            if (notes.isEmpty() || notes.size != durations.size || notes.any { it != -1 && it !in 24..108 } || durations.any { !it.isFinite() || it <= 0 || it > 8 }) {
                result.error("INVALID_SEQUENCE", "Invalid vocal exercise sequence", null)
                return@setMethodCallHandler
            }
            val generation = synchronized(vocalLock) {
                vocalGeneration += 1
                releaseVocalTrack()
                vocalGeneration
            }
            Thread {
                try {
                    val rate = 22050
                    val totalBeats = durations.sum()
                    val totalSeconds = totalBeats * 60.0 / bpm
                    if (totalSeconds > 900) throw IllegalArgumentException("Exercise exceeds audio limit")
                    val count = (rate * totalSeconds).toInt().coerceAtLeast(1)
                    val samples = ShortArray(count)
                    var elapsedBeats = 0.0
                    notes.forEachIndexed { index, midi ->
                        if (synchronized(vocalLock) { generation != vocalGeneration || destroyed }) {
                            runOnUiThread { result.success(null) }
                            return@Thread
                        }
                        val start = (elapsedBeats * 60.0 / bpm * rate).toInt()
                        val length = (durations[index] * 60.0 / bpm * rate * .82).toInt()
                        if (midi >= 0) mixPianoTone(samples, start, length, midi, rate, 6000.0)
                        elapsedBeats += durations[index]
                    }
                    if (metronome) {
                        var beatIndex = 0
                        while (beatIndex * 60.0 / bpm < totalSeconds) {
                            val start = (beatIndex * 60.0 / bpm * rate).toInt()
                            mixPianoTone(samples, start, (rate * .045).toInt(), if (beatIndex % 4 == 0) 90 else 84, rate, 2300.0)
                            beatIndex++
                        }
                    }
                    val track = AudioTrack(AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, samples.size * 2, AudioTrack.MODE_STATIC)
                    track.write(samples, 0, samples.size)
                    val admitted = synchronized(vocalLock) {
                        if (generation != vocalGeneration || destroyed) null else {
                            vocalTrack = track
                            track.play()
                            true
                        }
                    }
                    if (admitted == true) {
                        synchronized(vocalLock) {
                            if (vocalTrack === track) {
                                vocalRemainingMs = (totalSeconds * 1000).toLong()
                                scheduleVocalRelease(track, vocalRemainingMs)
                            }
                        }
                        runOnUiThread { result.success(null) }
                    } else {
                        track.release()
                        runOnUiThread { result.success(null) }
                    }
                } catch (e: Exception) { runOnUiThread { result.error("AUDIO", e.message, null) } }
            }.start()
        }
        // Capture cold launch before setIntent() can replace it on a warm launch.
        initialRequest = enqueueShare(intent?.let { Intent(it) }, initial = true)

        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "releaseCapturedWebView" -> {
                    val identifier = call.argument<Number>("identifier")?.toLong()
                    if (identifier == null || identifier < 0) {
                        result.error("INVALID_WEBVIEW", "Invalid captured WebView", null)
                    } else {
                        // Supported plugin external API; never change its client,
                        // sandbox, provider, cookies or security configuration.
                        @Suppress("DEPRECATION")
                        val view = WebViewFlutterAndroidExternalApi.getWebView(flutterEngine, identifier)
                        if (view == null) {
                            result.success(false)
                        } else {
                            (view.parent as? ViewGroup)?.removeView(view)
                            view.stopLoading()
                            view.destroy()
                            result.success(true)
                        }
                    }
                }
                "getInitialShare" -> {
                    if (initialConsumed || initialResult != null) {
                        result.success(null)
                    } else {
                        initialResult = result
                        drainCompletedShares()
                    }
                }
                "clearInitialShare" -> {
                    initialConsumed = true
                    initialRequest?.let { request ->
                        cancelRead(request)
                        request.payload = null
                        request.complete = true
                    }
                    initialResult?.success(null)
                    initialResult = null
                    drainCompletedShares()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun mixPianoTone(buffer: ShortArray, start: Int, length: Int, midi: Int, rate: Int, amplitude: Double) {
        val end = minOf(buffer.size, start + length)
        val frequency = 440.0 * Math.pow(2.0, (midi - 69) / 12.0)
        for (index in start.coerceAtLeast(0) until end) {
            val local = index - start
            val t = local.toDouble() / rate
            val releaseFrames = minOf(rate / 100, length)
            val release = if (local >= length - releaseFrames) {
                (length - 1 - local).coerceAtLeast(0).toDouble() / releaseFrames
            } else 1.0
            val envelope = minOf(1.0, local / 180.0) * Math.exp(-4.0 * t) * release
            val tone = sin(2 * Math.PI * frequency * t) + .32 * sin(4 * Math.PI * frequency * t) + .12 * sin(6 * Math.PI * frequency * t) + .04 * sin(8 * Math.PI * frequency * t)
            buffer[index] = (buffer[index] + tone * envelope * amplitude).toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    private fun releaseVocalTrack() {
        vocalRelease?.let(mainHandler::removeCallbacks)
        vocalRelease = null
        vocalRemainingMs = 0L
        vocalReleaseAtMs = 0L
        vocalTrack?.let { track ->
            try { track.pause(); track.flush(); track.release() } catch (_: Exception) { }
        }
        vocalTrack = null
    }

    private fun scheduleVocalRelease(track: AudioTrack, delayMs: Long) {
        vocalRelease?.let(mainHandler::removeCallbacks)
        vocalRemainingMs = delayMs.coerceAtLeast(0L)
        vocalReleaseAtMs = SystemClock.elapsedRealtime() + vocalRemainingMs
        val release = Runnable {
            synchronized(vocalLock) {
                if (vocalTrack === track) {
                    track.release()
                    vocalTrack = null
                    vocalRelease = null
                    vocalRemainingMs = 0L
                    vocalReleaseAtMs = 0L
                }
            }
        }
        vocalRelease = release
        mainHandler.postDelayed(release, vocalRemainingMs)
    }

    private fun stopVocalAudio() {
        synchronized(vocalLock) {
            vocalGeneration += 1
            vocalRelease?.let(mainHandler::removeCallbacks)
            vocalRelease = null
            releaseVocalTrack()
        }
    }

    override fun onStop() {
        stopVocalAudio()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        enqueueShare(Intent(intent), initial = false)
    }

    private fun enqueueShare(intent: Intent?, initial: Boolean): ShareRequest? {
        if (destroyed || (!initial && intent?.action != Intent.ACTION_SEND)) return null
        // Bound retained intents/payloads as well as the executor queue.
        if (requests.size >= MAX_PENDING_SHARES) return null
        val request = ShareRequest(initial, (++nextRequestId).toString(), ShareIntentHandler.ReadOperation())
        requests.addLast(request)
        if (!initial) {
            // Dart binds the request to the current session before provider IO.
            methodChannel?.invokeMethod("onShareStarted", mapOf("requestId" to request.id))
        }
        request.timeout = Runnable {
            if (!request.complete) {
                cancelRead(request)
                finishShare(request, mapOf(
                    "type" to "error",
                    "error" to "FILE_READ_TIMEOUT",
                    "errorMessage" to "O aplicativo de origem demorou para responder. Compartilhe o arquivo novamente.",
                ))
            }
        }.also { mainHandler.postDelayed(it, READ_TIMEOUT_MS) }
        try {
            request.future = ioExecutor.submit {
                val payload = try {
                    shareIntentHandler?.processIntent(intent, request.read)
                } catch (_: Exception) {
                    mapOf(
                        "type" to "error",
                        "error" to "FILE_READ_ERROR",
                        "errorMessage" to "Não foi possível ler o conteúdo compartilhado.",
                    )
                }
                mainHandler.post {
                    if (!destroyed && !request.complete) finishShare(request, payload)
                    else discardFiles(request)
                }
            }
        } catch (_: RejectedExecutionException) {
            cancelRead(request)
            finishShare(request, mapOf(
                "type" to "error",
                "error" to "FILE_READ_UNAVAILABLE",
                "errorMessage" to "A leitura do compartilhamento está ocupada. Tente novamente.",
            ))
        }
        return request
    }

    private fun finishShare(request: ShareRequest, payload: Map<String, Any?>?) {
        request.timeout?.let { mainHandler.removeCallbacks(it) }
        request.complete = true
        request.payload = payload?.plus("requestId" to request.id)
        drainCompletedShares()
    }

    private fun drainCompletedShares() {
        while (requests.isNotEmpty() && requests.first().complete) {
            val request = requests.first()
            if (request.initial && !initialConsumed) {
                val result = initialResult ?: return
                initialConsumed = true
                initialResult = null
                initialRequest = null
                result.success(request.payload)
            } else if (!request.initial && request.payload != null) {
                methodChannel?.invokeMethod("onShareReceived", request.payload)
            }
            requests.removeFirst()
        }
    }

    private fun discardFiles(request: ShareRequest) {
        try {
            cancellationExecutor.execute { request.read.discardFiles() }
        } catch (_: RejectedExecutionException) {
            // A cancelled worker also removes its files when provider IO exits.
        }
    }

    private fun cancelRead(request: ShareRequest) {
        request.timeout?.let { mainHandler.removeCallbacks(it) }
        request.read.markCancelled()
        request.future?.cancel(true)
        ioExecutor.purge()
        try {
            // Provider cancellation/close can block too, so keep them off main.
            cancellationExecutor.execute { request.read.cancelResources() }
        } catch (_: RejectedExecutionException) {
            // The worker checks cancellation before/after IO and cleans up.
        }
    }

    override fun onDestroy() {
        destroyed = true
        methodChannel?.setMethodCallHandler(null)
        requests.forEach { cancelRead(it) }
        requests.clear()
        initialResult?.success(null)
        initialResult = null
        ioExecutor.shutdownNow()
        cancellationExecutor.shutdown()
        super.onDestroy()
    }
}
